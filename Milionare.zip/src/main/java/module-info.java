module hr.algebra.java2.milionare.milionare {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens hr.algebra.java2.milionare.milionare to javafx.fxml;
    exports hr.algebra.java2.milionare.milionare;
}