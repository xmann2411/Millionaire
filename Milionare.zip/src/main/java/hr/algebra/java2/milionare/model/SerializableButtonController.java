package hr.algebra.java2.milionare.model;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class SerializableButtonController implements Serializable {

    @FXML
    private ListView<QuestionModel> listView;

    @FXML
    private TextField fieldName;
    @FXML
    private TextField fieldA;
    @FXML
    private TextField fieldB;
    @FXML
    private TextField fieldC;
    @FXML
    private TextField fieldD;

    public void onAdd() {

        QuestionModel question = new QuestionModel();
        question.text.setValue(fieldName.getText());
        question.answerA.setValue(fieldA.getText());
        question.answerB.setValue(fieldB.getText());
        question.answerC.setValue(fieldC.getText());
        question.answerD.setValue(fieldD.getText());

        listView.getItems().add(question);
    }

    public void onSave() {
        var list = listView.getItems()
                .stream()
                .map(QuestionModel::toData)
                .collect(Collectors.toList());

        /*var writer = new ObjectMapper();
        writer.writeValue(new File("data.json"), list);*/
    }


}
