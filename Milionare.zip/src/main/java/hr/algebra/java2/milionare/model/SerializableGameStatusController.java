package hr.algebra.java2.milionare.model;

//serijaliziramo stanje igre: playera, score, currentQuestion, Anwser

import javafx.scene.image.ImageView;

public class SerializableGameStatusController {

    private String currentQuestion;
    private String answerToCurrentQuestion;

    private Integer points;

    //private HelpButtonsStatus halfAndHalf;
    //private HelpButtonsStatus helpPhone;
    //private HelpButtonsStatus helpAudience;

    private ImageView prizesTable;
    private ImageView halfAndHalf;
    private ImageView helpPhone;
    private ImageView helpAudience;

    //private PlayerDetails playerOneDetails;
    //private PlayerDetails playerTwoDetails;


    public SerializableGameStatusController(String currentQuestion, String answerToCurrentQuestion, Integer points, ImageView prizesTable, ImageView halfAndHalf, ImageView helpPhone, ImageView helpAudience) {
        this.currentQuestion = currentQuestion;
        this.answerToCurrentQuestion = answerToCurrentQuestion;
        this.points = points;
        this.prizesTable = prizesTable;
        this.halfAndHalf = halfAndHalf;
        this.helpPhone = helpPhone;
        this.helpAudience = helpAudience;
    }

    public String getCurrentQuestion() {
        return currentQuestion;
    }

    public String getAnswerToCurrentQuestion() {
        return answerToCurrentQuestion;
    }

    public Integer getPoints() {
        return points;
    }

    public ImageView getHalfAndHalf() {
        return halfAndHalf;
    }

    public ImageView getHelpPhone() {
        return helpPhone;
    }

    public ImageView getHelpAudience() {
        return helpAudience;
    }

    public ImageView getPrizesTable() {
        return prizesTable;
    }
}
