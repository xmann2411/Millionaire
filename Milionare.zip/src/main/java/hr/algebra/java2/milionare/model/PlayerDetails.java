package hr.algebra.java2.milionare.model;

public class PlayerDetails {
    private String playerName;

    public PlayerDetails(String playerName){
        this.playerName = playerName;
    }

    public void setPlayerName(String playerName){
        this.playerName = playerName;
    }
}
