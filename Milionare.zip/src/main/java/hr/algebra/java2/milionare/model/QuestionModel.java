package hr.algebra.java2.milionare.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class QuestionModel {

    //public static int Question;
    public StringProperty text = new SimpleStringProperty();
    public StringProperty answerA = new SimpleStringProperty();
    public StringProperty answerB = new SimpleStringProperty();
    public StringProperty answerC = new SimpleStringProperty();
    public StringProperty answerD = new SimpleStringProperty();

    public Question toData(){
        return new Question(text.get(), answerA.get(), answerB.get(), answerC.get(), answerD.get());
    }

    public class Question {

        private String text;

        private Answer answerA;
        private Answer answerB;
        private Answer answerC;
        private Answer answerD;

        public Question(String text, String s, String s1, String s2, String s3) { }

        public Question(String text, Answer answerA, Answer answerB, Answer answerC, Answer answerD) {
            this.text = text;
            this.answerA = answerA;
            this.answerB = answerB;
            this.answerC = answerC;
            this.answerD = answerD;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public Answer getAnswerA() {
            return answerA;
        }

        public void setAnswerA(Answer answerA) {
            this.answerA = answerA;
        }

        public Answer getAnswerB() {
            return answerB;
        }

        public void setAnswerB(Answer answerB) {
            this.answerB = answerB;
        }

        public Answer getAnswerC() {
            return answerC;
        }

        public void setAnswerC(Answer answerC) {
            this.answerC = answerC;
        }

        public Answer getAnswerD() {
            return answerD;
        }

        public void setAnswerD(Answer answerD) {
            this.answerD = answerD;
        }

        public QuestionModel toModel(){
            var model = new QuestionModel();
            model.text.set(text);
            model.answerA.set(answerA.toString());
            model.answerB.set(answerB.toString());
            model.answerC.set(answerC.toString());
            model.answerD.set(answerD.toString());
            return model;
        }
    }


}
