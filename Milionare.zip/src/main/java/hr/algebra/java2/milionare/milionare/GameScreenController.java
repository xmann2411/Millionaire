package hr.algebra.java2.milionare.milionare;

import hr.algebra.java2.milionare.model.Answer;
import hr.algebra.java2.milionare.model.QuestionModel;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.ImageInput;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.awt.Color.BLACK;
import static java.awt.Color.GREEN;
import static javafx.scene.paint.Color.LIGHTSALMON;

public class GameScreenController {

    /**
     *  int callQuestions;
     *
     *  public void init()
     *  {
     *      callQuestions = 0;
     *  }
     *
     */


    /** PICTURES **/
    Image correctImage1 = new Image(getClass().getResource("images/MoneyTree-1.png").toString(), true);
    Image correctImage2 = new Image(getClass().getResource("images/MoneyTree-2.png").toString(), true);
    Image correctImage3 = new Image(getClass().getResource("images/MoneyTree-3.png").toString(), true);
    Image correctImage4 = new Image(getClass().getResource("images/MoneyTree-4.png").toString(), true);
    Image correctImage5 = new Image(getClass().getResource("images/MoneyTree-5.png").toString(), true);
    Image correctImage6 = new Image(getClass().getResource("images/MoneyTree-6.png").toString(), true);
    Image correctImage7 = new Image(getClass().getResource("images/MoneyTree-7.png").toString(), true);
    Image correctImage8 = new Image(getClass().getResource("images/MoneyTree-8.png").toString(), true);
    Image correctImage9 = new Image(getClass().getResource("images/MoneyTree-9.png").toString(), true);
    Image correctImage10 = new Image(getClass().getResource("images/MoneyTree-10.png").toString(), true);
    Image correctImage11 = new Image(getClass().getResource("images/MoneyTree-11.png").toString(), true);
    Image correctImage12 = new Image(getClass().getResource("images/MoneyTree-12.png").toString(), true);
    Image correctImage13 = new Image(getClass().getResource("images/MoneyTree-13.png").toString(), true);
    Image correctImage14 = new Image(getClass().getResource("images/MoneyTree-14.png").toString(), true);
    Image correctImage15 = new Image(getClass().getResource("images/MoneyTree-15.png").toString(), true);

    private String audience = String.valueOf(new String[]{"@src/main/images/audience.PNG"});
    private String audienceCalled = String.valueOf(new String[]{"@src/main/images/audienceCalled.PNG"});

    String pictureAudidence = "@src/main/images/audience.PNG";

    private String phone = String.valueOf(new String[]{"@src/main/images/phone.PNG"});
    private String phoneCalled = String.valueOf(new String[]{"@src/main/images/phoneCalled.PNG"});

    private String fiftyFifty = String.valueOf(new String[]{"@src/main/images/fiftyFifty.PNG"});
    private String fiftyFiftyCalled = String.valueOf(new String[]{"@src/main/images/fiftyFiftyCalled.PNG"});


    @FXML
    private Button getNextQuestionButton;

    @FXML
    private Button questionButton;

    @FXML
    private Button answerOneButton;

    @FXML
    private Button answerTwoButton;

    @FXML
    private Button answerThreeButton;

    @FXML
    private Button answerFourButton;

    @FXML
    private ImageView audienceImageView;

     @FXML
    private ImageView phoneImageView;

     @FXML
    private ImageView fiftyFiftyImageView;

     @FXML
     private ImageView prizesTableImageView;

     private int playerOnePoints = 0;
     private int playerTwoPoints = 0;

     public static Boolean playerOneTurn;


     boolean correctAnswer = false;


     //List<Button> Questions;
     //List<QuestionModel.Question> Answers;

    List<String> pitanja = new ArrayList<String>();

    //pitanja.add("ko je");


    private class Pitanje{

        private String Question;
        private String AwnserA;
        private String AwnserB;
        private String AwnserC;
        private String AwnserD;

        public Pitanje(String bla, String bla1, String bla2, String bla3, String bla4) {

        }
    }

    List<Pitanje> lista = new ArrayList<>();

    Pitanje prvo = new Pitanje("bla", "bla", "bla", "bla", "bla");

    //lista.add(prvo);

    List<QuestionModel.Question> list = new ArrayList<QuestionModel.Question>();

    //list.add();

    //QuestionModel.Question.

     //List<QuestionModel.Question> pitanja = new ArrayList<>(QuestionModel.Question);



     //QuestionModel.Question[1] = set

     //for(int i = 1, i <= )

    int numberOfQuestion = 0;

    public void getNextQuestion(){
        //svaki klik se inkrementa
        //number of question je index
        numberOfQuestion = numberOfQuestion + 1;
        playerOnePoints = numberOfQuestion + 1;

        System.out.println("Player one turn!");

        if (numberOfQuestion == 0){
            questionButton.setText("Who wants to be a Milionaire");
            answerOneButton.setText("  ");
            answerTwoButton.setText("  ");
            answerThreeButton.setText("  ");
            answerFourButton.setText("  ");
        } else if (numberOfQuestion == 1) {
            //titleovi
            playerOnePoints = 1;
            questionButton.setText("What's 2 + 2? ");
            answerOneButton.setText(" 2 ");
            answerTwoButton.setText(" 4 ");
            answerThreeButton.setText(" 6 ");
            answerFourButton.setText(" 8 ");
        } else if (numberOfQuestion == 2) {
            playerOnePoints = 2;
            questionButton.setText("What is the capital of Croatia?");
            answerOneButton.setText(" Split ");
            answerTwoButton.setText(" Zagreb ");
            answerThreeButton.setText(" Vinkovci ");
            answerFourButton.setText(" Sarajevo ");
        } else if (numberOfQuestion == 3) {
            playerOnePoints = 3;
            questionButton.setText("How do you say backery in French? ");
            answerOneButton.setText(" la boulangerie ");
            answerTwoButton.setText(" el croassan place ");
            answerThreeButton.setText(" gate d'pane ");
            answerFourButton.setText(" pekara ");
        } else if (numberOfQuestion == 4) {
            playerOnePoints = 4;
            questionButton.setText("Where is the 2022 Soccer World Cup?");
            answerOneButton.setText(" China ");
            answerTwoButton.setText(" Croatia ");
            answerThreeButton.setText(" Brasil ");
            answerFourButton.setText(" Qatar ");
        } else if (numberOfQuestion == 5) {
            playerOnePoints = 5;
            questionButton.setText("Who is the president of Mexico?");
            answerOneButton.setText(" Andrés Manuel López Obrador ");
            answerTwoButton.setText(" Jair Bolsonaro ");
            answerThreeButton.setText(" Gustavo Petro ");
            answerFourButton.setText(" Marcelo Rebelo de Sousa ");
        }

        /**provjera tocnosti pitanja**/

        List<String> listOfQuestions
                = new ArrayList<>();

    }


    Image audienceImage = new Image(getClass().getResource("images/audience.PNG").toString(), true);
    Image phoneImage = new Image(getClass().getResource("images/phone.PNG").toString(), true);
    Image fiftyFiftyImage = new Image(getClass().getResource("images/fiftyFifty.PNG").toString(), true);
    Image audienceCalledImage = new Image(getClass().getResource("images/audienceCalled.PNG").toString(), true);
    Image phoneCalledImage = new Image(getClass().getResource("images/phoneCalled.PNG").toString(), true);
    Image fiftyFiftyCalledImage = new Image(getClass().getResource("images/fiftyFiftyCalled.PNG").toString(), true);
    public void init(){
        audienceImageView.setImage(audienceImage);
        phoneImageView.setImage(phoneImage);
        fiftyFiftyImageView.setImage(fiftyFiftyImage);
    }

    private boolean usedAudience;
    private boolean usedCall;
    private boolean used5050;

    public void getAskingAudience() {

        //if usedAudience then its second players turn
        if(usedAudience && (numberOfQuestion == 1 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 2 && fiftyFiftyImageView.isFocused()))
        {
            System.out.println("Player two turn!");
            playerTwoPoints = numberOfQuestion;
            answerTwoButton.setText(String.valueOf(Color.BLACK));
        }
        else if (usedAudience && (numberOfQuestion == 3 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 4 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 5 && fiftyFiftyImageView.isFocused()))
        {
            System.out.println("Player two turn!");
            playerTwoPoints = numberOfQuestion;
            answerOneButton.setText(String.valueOf(Color.BLACK));
        }
        else if(!usedAudience){
            return;
        }

        /*if(usedAudience && (numberOfQuestion == 1 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 2 && fiftyFiftyImageView.isFocused()))
            {
                answerTwoButton.setText(String.valueOf(Color.BLACK));
            }
        else if (usedAudience && (numberOfQuestion == 3 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 4 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 5 && fiftyFiftyImageView.isFocused()))
            {
                answerOneButton.setText(String.valueOf(Color.BLACK));
            }
        else if(!usedAudience){
            return;
        }*/

        /*if (usedAudience) {
            return;
        }
        usedAudience = true;
        audienceImageView.setImage(audienceCalledImage);

        if (numberOfQuestion == 1 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 2 && fiftyFiftyImageView.isFocused()) {
            answerTwoButton.setText(String.valueOf(Color.BLACK));
            //answerTwoButton.setBackground(Color.LIGHTSALMON);
        } else if (numberOfQuestion == 3 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 4 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 5 && fiftyFiftyImageView.isFocused()) {
            answerOneButton.setText(String.valueOf(Color.BLACK));
            //answerOneButton.setBackground(LIGHTSALMON);
        }*/
    }



    public void getCallHelp() {
        if (usedCall) {
            return;
        }
        usedCall = true;
        phoneImageView.setImage(phoneCalledImage);

        if (numberOfQuestion == 1 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 2 && fiftyFiftyImageView.isFocused()) {
            answerTwoButton.setText(String.valueOf(GREEN));
            //answerTwoButton.setBackground(Color.LIGHTGREEN);
        } else if (numberOfQuestion == 3 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 4 && fiftyFiftyImageView.isFocused()
                || numberOfQuestion == 5 && fiftyFiftyImageView.isFocused()) {
            answerOneButton.setText(String.valueOf(GREEN));
            //answerOneButton.setBackground(Color.LIGHTGREEN);

        }
    }

    public void getHalfAndHalf(){
        if(used5050){
            return;
        }
        used5050 = true;
        fiftyFiftyImageView.setImage(fiftyFiftyCalledImage);

        /**koristenje gumba za pola pola**/
        if(numberOfQuestion == 1 && fiftyFiftyImageView.isFocused()
         || numberOfQuestion == 2 && fiftyFiftyImageView.isFocused()){
            answerThreeButton.setText(String.valueOf(Color.BLACK));
            answerFourButton.setText(String.valueOf(Color.BLACK));
        } else if(numberOfQuestion == 3 && fiftyFiftyImageView.isFocused()
            || numberOfQuestion == 4 && fiftyFiftyImageView.isFocused()
            || numberOfQuestion == 5 && fiftyFiftyImageView.isFocused()){
            answerTwoButton.setText(String.valueOf(Color.BLACK));
            answerThreeButton.setText(String.valueOf(Color.BLACK));
        }
    }

    //pitanje
    //status jel T il N
    //svako pitanje je funkc

    //answers[1] i za buton

    public void getSecondQuestionIsRight(){
        if(numberOfQuestion == 1 && answerTwoButton.isFocused()){
            answerTwoButton.setOpacity(100);
            answerTwoButton.setText(String.valueOf(Color.BLACK));
            /*answerTwoTextField.setBackground(Color.GREEN);*/
            answerTwoButton.setBackground(new Background(new BackgroundFill(Color.GREEN, CornerRadii.EMPTY, Insets.EMPTY)));

            answerOneButton.setOpacity(100);
            answerOneButton.setText(String.valueOf(Color.WHITE));
            /*answerOneTextField.setBackground(Color.BLACK);*/
            answerTwoButton.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

            answerThreeButton.setOpacity(100);
            answerThreeButton.setText(String.valueOf(Color.WHITE));
            /*answerThreeTextField.setBackground(Color.BLACK);*/
            answerTwoButton.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

            answerThreeButton.setOpacity(100);
            answerThreeButton.setText(String.valueOf(Color.WHITE));
            /*answerThreeTextField.setBackground(Color.BLACK);*/
            answerTwoButton.setBackground(new Background(new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, Insets.EMPTY)));

        } else {
            return;
        }
    }



    //saving game (from lara)

    /*public void saveGame() throws IOException {

        Stage stage = HelloApplication.getMainStage();

        stage.setTitle("Game screen!");
        stage.setScene(scene);
        stage.show();

        //moje
        List<Seri>

        //larino
        // serializableTextFields = new SerializableTextField(insertedHiddenWord,pointsForLetter,lives,txtRightLetters.getText(),txtWrongLetters.getText());

        try( ObjectOutputStream serializer = new ObjectOutputStream( new FileOutputStream("savedGame.ser"))){;

            serializer.writeObject(serializableTextFields);
            System.out.println("Game is saved.");
        }

    }*/



    public void loadGame() {

    }

    public void generateDocumentation(){

        File documentationFile = new File("documentation.html");

        try {
            List<Path> paths = Files.walk(Paths.get("."))
                    .filter(path -> path.getFileName().toString().endsWith(".class"))
                    .collect(Collectors.toList());

            for (Path path : paths) {
                System.out.println("Path: " + path);
                String[] tokens = path.toString().split(Pattern.quote(System.getProperty("file.separator")));

                Boolean startBuildingPath = false;

                StringBuilder sb = new StringBuilder();

                for (String token : tokens) {
                    if("classes".equals(token)){
                        startBuildingPath = true;
                        continue;
                    }

                    if (startBuildingPath){

                        if (token.endsWith(".class")){
                            sb.append(token.substring(0, token.indexOf(".")));
                        }
                        else {
                            sb.append(token);
                            sb.append(".");
                        }
                    }
                    else{
                        continue;
                    }
                }

                if ("module-info".equals(sb.toString())){
                    continue;
                }

                System.out.println("Fully qualified name: " + sb.toString());

                FileWriter writer = new FileWriter(documentationFile);

                writer.write("<!DOCTYPE html>");
                writer.write("<html>");
                writer.write("<title>Project documentation</title>");
                writer.write("</head>");
                writer.write("<body>");
                writer.write("<h1>Project documentation</h1>");
                writer.write("<p>Class list</p>");

                try {
                    Class<?> clazz = Class.forName(sb.toString());

                    writer.write("<h2>" + clazz.getName() + "<\\h2>\\n");

                    Constructor[] constructors = clazz.getConstructors();

                    System.out.println("<h3>Constructors:<\\h3>");

                    for(Constructor c : constructors){
                        System.out.println("<h4>Constructor: " + c.getName() + "");
                    }

                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }

                //System.out.println("Tokens: ");
                //Arrays.stream(tokens).forEach(System.out::println);
            }



        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error while generating documentation!");
            alert.setHeaderText("Cannot find the files");
            alert.setContentText("The class files cannot be accessed.");

            alert.showAndWait();
        }

    }



}
