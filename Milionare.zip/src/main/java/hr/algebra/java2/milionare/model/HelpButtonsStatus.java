package hr.algebra.java2.milionare.model;

public enum HelpButtonsStatus {
    Used,
    NotUsed
}
