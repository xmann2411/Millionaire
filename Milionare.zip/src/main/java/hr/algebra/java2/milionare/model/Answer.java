package hr.algebra.java2.milionare.model;

public class Answer {
    private String text;

}
